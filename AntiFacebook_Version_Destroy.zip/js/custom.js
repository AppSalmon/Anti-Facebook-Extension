let htmlTemplate = `
<div class="facebookblock"></div>
<div class="facebookblock2"></div>

`;


window.onload = function(){
  const wrapperObject = document.querySelector('body > div');
  if (wrapperObject !== null)
  {
    const now = new Date();
    const currentHour = now.getHours();
    if(currentHour > 20)
    {
      setTimeout(function() {
        wrapperObject.innerHTML+=htmlTemplate;
      }, 1 * 1 * 1000);
    }
    else
    {
      setTimeout(function() {
        wrapperObject.innerHTML+=htmlTemplate;
      }, 1 * 1 * 1000);
    }
  }
  console.log(wrapperObject);
}



setTimeout(function() {
  

  var randomNumber = Math.floor(Math.random() * 9);

  switch (randomNumber) {
    case 0:
      alert("Đừng để Facebook chiếm giữ thời gian và tâm trí của bạn. Hãy dành thời gian đó để làm những điều quan trọng hơn.");
      break;
    case 1:
      alert("Bạn không cần Facebook để cảm thấy kết nối với thế giới xung quanh. Hãy tìm cách kết nối với mọi người một cách khác.");
      break;
    case 2:
      alert("Bạn sẽ không bao giờ biết mình đã bỏ lỡ những gì nếu không thử bỏ Facebook ít nhất là một thời gian.");
      break;
    case 3:
      alert("Nếu bạn thấy Facebook không mang lại lợi ích cho cuộc sống của mình, hãy dừng sử dụng nó.");
      break;
    case 4:
      alert("Hãy tưởng tượng những gì bạn có thể làm với thời gian và sức mạnh của mình nếu bạn không dùng Facebook.");
      break;
    case 5:
      alert("Không ai có thể đoán được sẽ có bao nhiêu thời gian chúng ta còn lại để sống. Hãy sử dụng nó cho những điều có ý nghĩa và giá trị hơn là lãng phí trên Facebook.");
      break;
    case 6:
      alert("Bạn không phải là một số trên Facebook. Hãy tập trung vào cuộc sống thực và những mối quan hệ thực sự của bạn.");
      break;
    case 7:
      alert("Bỏ Facebook để tìm thấy sự yên tĩnh và tràn đầy năng lượng để tập trung vào những điều quan trọng hơn.");
      break;
    case 8:
      alert("Hãy tưởng tượng những gì bạn có thể làm với thời gian và sức mạnh của mình nếu bạn không dùng Facebook.");
      break;
      
    default:
      alert("Nếu bạn muốn thay đổi cuộc đời của mình, hãy bắt đầu bằng việc bỏ Facebook.");
      break;
  }




}, 1 * 1 * 1000);

