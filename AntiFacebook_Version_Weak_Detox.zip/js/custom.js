let htmlTemplate = `
<div class="facebookblock">Facebook của bạn đã bị vô hiệu hóa🐣</div>
<div class="facebookblock2"></div>

`;


window.onload = function(){
  const wrapperObject = document.querySelector('body > div');
  if (wrapperObject !== null)
  {
    const now = new Date();
    const currentHour = now.getHours();
    if(currentHour > 20)
    {
      setTimeout(function() {
        wrapperObject.innerHTML+=htmlTemplate;
      }, 60 * 60 * 1000);
    }
    else
    {
      setTimeout(function() {
        wrapperObject.innerHTML+=htmlTemplate;
      }, 30 * 60 * 1000);
    }
  }
  console.log(wrapperObject);
}



